Instructions:

1) Need to Install .NET 4.5		( http://www.microsoft.com/en-in/download/details.aspx?id=30653 )


2) Need to install Silverlight latest	( http://www.microsoft.com/silverlight/ )


3) Double click '3DDemoTest/Car_shelf_wpfApp.exe'